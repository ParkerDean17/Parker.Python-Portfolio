# Parker Dean
# Final project - Flappy Bird
# 5-9-19


import pygame
import random
from fb_settings import *
from fb_sprites import *
from os import path


# classes
class Game:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE) 
        self.clock = pygame.time.Clock()
        self.running = True
        self.font_name = pygame.font.match_font(FONT_NAME)
        self.load_data()

    def load_data(self):
        """load high score"""
    
        pygame.mixer.music.load("sounds/theme.wav")
        pygame.mixer.music.set_volume(0.9)
        self.dir = path.dirname(__file__)
        with open(path.join(self.dir, HS_FILE), 'w') as f:
            try:
                self.highscore = int(f.read())
            except:
                self.highscore = 0

    def new(self):
        """resets the game"""
        self.score = 0
        self.all_sprites = pygame.sprite.Group()
        self.platforms = pygame.sprite.Group()
        self.pipes = pygame.sprite.Group()
        
        self.player = Player()
        self.all_sprites.add(self.player)
        
        ground = Platform(0, HEIGHT-40, WIDTH,40)
        self.all_sprites.add(ground)
        self.platforms.add(ground)
        # starting pipes
        x = Pipe(WIDTH+60, 0, 40, 300)
        z = Pipe(WIDTH+60, HEIGHT, 40, 300)
        self.all_sprites.add(x,z)
        self.pipes.add(x,z)
        
        self.run()

    def run(self):
        """Runs game loop"""
        self.playing = True
        pygame.mixer.music.play(loops = -1)
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()

    def update(self):
        # fix this update box
        self.all_sprites.update()
        hits = pygame.sprite.spritecollide(self.player, self.platforms, False)
        if hits:
            self.player.pos.y = hits[0].rect.top
            self.player.vel.y = 0
        if len(self.pipes)< 1:
            offsets = [-100, -75, -50, -25, 0, 25, 50, 75, 100]
            offset = random.choice(offsets)
            x = Pipe(WIDTH+60, 0+offset, 40, 340)
            z = Pipe(WIDTH+60, HEIGHT+offset, 40, 340)
            self.all_sprites.add(x,z)
            self.pipes.add(x,z)
        hitspipe = pygame.sprite.spritecollide(self.player,self.pipes,False)
        if hitspipe:
            for pipe in self.pipes:
                self.vel = (0,0)
                self.acc = (0,0)
                pipe.play = False
            self.player.die()
            self.playing = False
        for pipe in self.pipes:
            if pipe.pos.x < 1:
                self.score += 1
    
    def events(self):
        for event in pygame.event.get():
            # check for closing window
            if event.type == pygame.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.player.jump()   

    def draw(self):
        self.screen.fill(BGCOLOR)
        self.all_sprites.draw(self.screen)
        self.draw_text(str(self.score), 22, WHITE, 15, 15)
        pygame.display.flip()

    

    def show_start_screen(self):
        self.screen.fill(BGCOLOR)
        self.draw_text(TITLE, 48, WHITE, WIDTH/2, HEIGHT/4)
        self.draw_text("Press space to jump", 22, WHITE, WIDTH/2, HEIGHT/2)
        self.draw_text("Press a key to play", 22, WHITE, WIDTH/2, HEIGHT*3/4)
        self.draw_text("High Score: " + str(self.highscore), 22, WHITE, WIDTH/2, 15)
        pygame.display.flip()
        self.wait_for_key()
        
    def show_go_screen(self):
        if not self.running:
            return
        self.screen.fill(BGCOLOR)
        self.draw_text("GAME OVER", 48, WHITE, WIDTH/2, HEIGHT/4)
        self.draw_text("Score: " + str(self.score), 22, WHITE, WIDTH/2, HEIGHT/2)
        self.draw_text("Press a key to play again", 22, WHITE, WIDTH/2, HEIGHT*3/4)
        pygame.display.flip()
        self.wait_for_key()

    def wait_for_key(self):
        waiting = True
        while waiting:
            self.clock.tick(FPS)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if event.type == pygame.KEYUP:
                    waiting = False
    
    def draw_text(self, text, size, color, x, y):
        font_name = pygame.font.match_font('arial')
        font = pygame.font.Font(font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        self.screen.blit(text_surface, text_rect)


    

g = Game()
g.show_start_screen()
while g.running:
    g.new()
    g.show_go_screen()

pygame.quit()
