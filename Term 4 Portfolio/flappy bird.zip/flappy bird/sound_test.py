# Parker Dean
# 5-2-19

from superwires import games

games.init(screen_width=640, screen_height=480, fps=60)


# load sound fx
jump = games.load_sound("sounds/jump.wav")

# load themes
games.music.load("sounds/theme.mp3")

# create menu
choice = None
while choice != "0":
    print(
        """
        Sound and Music
        
        0 - Quit
        1 - Play jump sound
        2 - Loop jump sound
        3 - Stop jump sound
        4 - Play theme music
        5 - Loop theme music
        6 - Stop theme music
        """)
    choice = input("Choice: ")
    print()

    # exit
    if choice == "0":
        print("Good-bye ")
    # play missile sound
    elif choice == "1":
        jump.play()
        print("Playing jump sound.")
    # loop missile sound
    elif choice == "2":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        jump.play(loop)
        print("Looping jump sound.")
    # stop missile sound
    elif choice == "3":
        jump.stop()
        print("Stopping jump sound.")
    # play missile sound
    elif choice == "4":
        games.music.play()
        print("Playing theme music.")
    # loop missile sound
    elif choice == "5":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        games.music.play(loop)
        print("Looping theme music.")
    # stop missile sound
    elif choice == "6":
        games.music.stop()
        print("Stopping theme music.")
        
