# Parker Dean
# 5-2-19

from superwires import games

games.init(screen_width=640, screen_height=480, fps=60)


# load sound fx
shoot = games.load_sound("sounds/laser_shot.wav")
thrust = games.load_sound("sounds/thruster.wav")
explosion = games.load_sound("sounds/explosion.wav")
level = games.load_sound("sounds/level.wav")

# load themes
games.music.load("sounds/background_sound.wav")

# create menu
choice = None
while choice != "0":
    print(
        """
        Sound and Music
        
        0 - Quit
        1 - Play laser sound
        2 - Loop laser sound
        3 - Stop laser sound
        4 - Play theme music
        5 - Loop theme music
        6 - Stop theme music
        7 - Play thrust sound
        8 - Loop thrust sound
        9 - Stop thrust sound
        10 - Play level sound
        11 - Loop level sound
        12 - Stop level sound
        13 - Play explosion sound
        14 - Loop explosion sound
        15 - Stop explosion sound
        """)
    choice = input("Choice: ")
    print()

    # exit
    if choice == "0":
        print("Good-bye ")
    # play missile sound
    elif choice == "1":
        shoot.play()
        print("Playing laser sound.")
    # loop missile sound
    elif choice == "2":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        shoot.play(loop)
        print("Looping laser sound.")
    # stop missile sound
    elif choice == "3":
        shoot.stop()
        print("Stopping laser sound.")
    # play missile sound
    elif choice == "4":
        games.music.play()
        print("Playing theme music.")
    # loop missile sound
    elif choice == "5":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        games.music.play(loop)
        print("Looping theme music.")
    # stop missile sound
    elif choice == "6":
        games.music.stop()
        print("Stopping theme music.")
    # play missile sound
    elif choice == "7":
        thrust.play()
        print("Playing thrust sound.")
    # loop missile sound
    elif choice == "8":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        thrust.play(loop)
        print("Looping thrust sound.")
    # stop missile sound
    elif choice == "9":
        thrust.stop()
        print("Stopping thrust sound.")
    # play missile sound
    elif choice == "10":
        level.play()
        print("Playing level sound.")
    # loop missile sound
    elif choice == "11":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        level.play(loop)
        print("Looping level sound.")
    # stop missile sound
    elif choice == "12":
        level.stop()
        print("Stopping level sound.")
    # play missile sound
    elif choice == "13":
        explosion.play()
        print("Playing explosion sound.")
    # loop missile sound
    elif choice == "14":
        loop = int(input("Loop how many extra time? (-1 = forever): "))
        explosion.play(loop)
        print("Looping explosion sound.")
    # stop missile sound
    elif choice == "15":
        explosion.stop()
        print("Stopping explosion sound.")