# Parker Dean
# 4-10-19

from superwires import games, color
import random

"""Code comments i need to know"""
# width: is width of screen
# height: is height of screen
# fps: is Frames per second screen updates
# background: is the image behind
# all objects: is a list of all the sprites on the screen
# event_grab: is a boolean that determines if input is grabbed to screen,
#   true for input grabbed to screen. False for input not grabbed to screen
# add(sprite): adds sprite to the graphics screen
# clear(): Removes all sprites from the graphics screen
# mainloop(): Starts the graphics screen's main loop
# quit(): closes the graphics window.


SCORE = 0

games.init(screen_width=853, screen_height=480, fps=60)


class Dropper(games.Sprite):

    def update(self):
        global SCORE
        # if self.right > games.screen.width or self.left < 0:
        #     self.dx = -self.dx
        #     SCORE += 1
        # if self.bottom > games.screen.height or self.top < 0:
        #     self.dy = -self.dy
        #     SCORE += 1

        if self.left > games.screen.width:
            self.right = 0
            SCORE += 1
        if self.right < 0:
            self.left = games.screen.width
            SCORE += 1
        if self.top > games.screen.height:
            self.bottom = 0
            SCORE += 1
        if self.bottom < 0:
            self.top = games.screen.height
            SCORE += 1

    def handle_collide(self):
        self.x = random.randrange(games.screen.width)
        self.y = random.randrange(games.screen.height)


class Pan(games.Sprite):
    """ A pan controlled by the mouse"""
    def update(self):
        """Move to moues coordinates"""
        self.x = games.mouse.x
        self.y = games.mouse.y
        self.check_collide()

    def check_collide(self):
        """Check for collisions"""
        global SCORE
        for strange_coin in self.overlapping_sprites:
            strange_coin.handle_collide()
            SCORE += 10


class ScText(games.Text):
    def update(self):
        self.value = SCORE


def main():
    bg_img = games.load_image("sprites/D2Background.jpg", transparent=False)
    strange_coin_img = games.load_image("sprites/D1StrangeCoin.png", transparent=True)
    pan_img = games.load_image("sprites/pan.jpg", transparent=True)
    
    games.screen.background = bg_img

    strange_coin = Dropper(image=strange_coin_img,
                           x=games.screen.width/2,
                           y=games.screen.height/2,
                           dx=random.randint(-10, 10),
                           dy=random.randint(-10, 10),
                           )
    # create pan object
    pan = Pan(image=pan_img,
              x=games.mouse.x,
              y=games.mouse.y)
    # create txt obj
    score = ScText(value=SCORE,
                   size=60,
                   is_collideable=False,
                   color=color.white,
                   x=550,
                   y=30)
    # draw objs to screen                      
    games.screen.add(strange_coin)
    games.screen.add(score)
    games.screen.add(pan)

    games.mouse.is_visible = False
    games.screen.event_grab = False
    # start mainloop
    games.screen.mainloop()
# keeps the screen open and funcitonal.

# game_over = games.Message(value = "Game Over",
#                           size = 100,
#                           color = color.red,
#                           x = gaems.screen.width/2
#                           y = games.screen.height/2,
#                           lifetime = 250,
#                           after_death = games.screen.quit)
# games.screen.add(game_over)


main()