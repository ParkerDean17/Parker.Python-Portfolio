# Parker Dean
# 4-30-19

from superwires import games

games.init(screen_width=1000, screen_height=500, fps=60)


class Ship(games.Sprite):
    pass


def main():
    # load date
    death_star = games.load_image("astroid_sprites/death_star.jpg", transparent=False)

    # draw to screen
    games.screen.background = death_star

    # game setup
    games.screen.mainloop()


main()