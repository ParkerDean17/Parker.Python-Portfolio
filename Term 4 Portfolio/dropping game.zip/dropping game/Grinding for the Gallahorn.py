# Parker Dean
# 4-18-19
# Grinding for the Gallahorn

# imports
from superwires import games, color
import random


# screen creation
games.init(screen_width=1137, screen_height=640, fps=60)

gameOver = False

# classes
class Dropper(games.Sprite):
    """the strange coin dropped"""
    # load the img
    image = games.load_image("sprites/D1StrangeCoin.png", transparent=True)
    speed = 4

    def __init__(self, x, y=225):
        super(Dropper, self).__init__(image=Dropper.image, x=x,
                                      y=y, dy=Dropper.speed)

    def update(self):
        if self.top > games.screen.height:
            self.destroy()
            self.end_game()

    def handle_caught(self):
        self.destroy()

    def end_game(self):
        global gameOver
        end_message = games.Message(value="No Gallahorn for you",
                                    size=120,
                                    color=color.blue,
                                    x=games.screen.width/2,
                                    y=games.screen.height/2,
                                    lifetime=8*games.screen.fps,
                                    after_death=games.screen.quit)
        games.screen.add(end_message)
        gameOver = True


class Pan(games.Sprite):
    """ A pan controlled by the mouse"""
    image = games.load_image("sprites/pan.png", transparent=True)

    def __init__(self):
        super(Pan, self).__init__(image=Pan.image,
                                  x=games.mouse.x,
                                  bottom=games.screen.height)

        self.score = games.Text(value=0, size=25, color=color.white,
                                top=5, right=games.screen.width-10)
        games.screen.add(self.score)

    def update(self):
        """Move to moues coordinates"""
        self.x = games.mouse.x
        if self.left < 0:
            self.left = 0
        if self.right > games.screen.width:
            self.right = games.screen.width

        self.check_catch()

    def check_catch(self):
        for dropper in self.overlapping_sprites:
            dropper.handle_caught()
            self.score.value += 10
            self.score.right = games.screen.width-10
        if gameOver == True:
            self.destroy()


class Baddy(games.Sprite):
    image = games.load_image("sprites/D2Ghaul.png", transparent=True)

    def __init__(self, y=80, speed=5, odds_change=100):
        super(Baddy, self).__init__(image=Baddy.image,
                                    x=games.screen.width/2,
                                    y=y,
                                    dx=speed)
        self.odds_change = odds_change
        self.time_til_drop = 0

    def update(self):
        if self.left < 0 or self.right > games.screen.width:
            self.dx = -self.dx
        elif random.randrange(self.odds_change) == 0:
            self.dx = -self.dx
            self.check_drop()

    def check_drop(self):
        if self.time_til_drop > 0:
            self.time_til_drop -= 1
        else:
            new_coin = Dropper(x=self.x, y=225)
            games.screen.add(new_coin)
            self.time_til_drop = random.randrange(0,2)


class ScText(games.Text):
    pass


# main
def main():
    # load images
    bg_img = games.load_image("sprites/D2Background.jpg", transparent=False)

    # create game objs
    the_pan = Pan()
    the_baddy = Baddy()
    the_dropper = Dropper(200)

    # draw objs to screen
    games.screen.background = bg_img
    games.screen.add(the_pan)
    games.screen.add(the_baddy)
    games.screen.add(the_dropper)

    # set up mouse
    games.mouse.is_visible = False
    games.screen.event_grab = True

    # start game loop
    games.screen.mainloop()


# start up
main()